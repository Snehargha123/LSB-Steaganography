#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "decode.h"
#include "types.h"
#include "common.h"

Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    if (argv[2] != NULL && strstr(argv[2], ".bmp") != NULL)
    {
        decInfo->stego_image_fname = argv[2];
    }
    else
    {
        printf("Invalid stego image file\n");
        return e_failure;
    }

    if (argv[3] == NULL)
    {
        decInfo->output_fname = "output.txt";
    }
    else
    {
        decInfo->output_fname = argv[3];
    }

    return e_success;
}

Status open_decode_files(DecodeInfo *decInfo)
{
    decInfo->fptr_stego_image = fopen(decInfo->stego_image_fname, "r");
    if (decInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->stego_image_fname);
        return e_failure;
    }

    decInfo->fptr_output_file = fopen(decInfo->output_fname, "w");
    if (decInfo->fptr_output_file == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->output_fname);
        return e_failure;
    }

    return e_success;
}

char decode_byte_from_lsb(char *image_buffer)
{
    char data = 0;
    for (int i = 0; i < 8; i++)
    {
        data = data << 1;
        data |= (image_buffer[i] & 1);
    }
    return data;
}

Status decode_data_from_image(char *data, int size, DecodeInfo *decInfo)
{
    char buffer[8];
    for (int i = 0; i < size; i++)
    {
        fread(buffer, 8, 1, decInfo->fptr_stego_image);
        data[i] = decode_byte_from_lsb(buffer);
    }
    return e_success;
}

Status decode_magic_string(DecodeInfo *decInfo)
{
    fseek(decInfo->fptr_stego_image, 54, SEEK_SET);
    decode_data_from_image(decInfo->magic_string, 2, decInfo);
    decInfo->magic_string[2] = '\0';

    if (strcmp(decInfo->magic_string, MAGIC_STRING) == 0)
    {
        return e_success;
    }
    return e_failure;
}

Status decode_size_from_lsb(int *size, DecodeInfo *decInfo)
{
    char str[32];
    fread(str, 32, 1, decInfo->fptr_stego_image);
    int value = 0;

    for (int i = 0; i < 32; i++)
    {
        value = (value << 1) | (str[i] & 1);
    }
    *size = value;
    return e_success;
}

Status decode_secret_file_extn_size(int *extn_size, DecodeInfo *decInfo)
{
    decode_size_from_lsb(extn_size, decInfo);
    return e_success;
}

Status decode_secret_file_extn(char *file_extn, DecodeInfo *decInfo)
{
    decode_data_from_image(file_extn, decInfo->extn_size, decInfo);
    file_extn[decInfo->extn_size] = '\0';
    return e_success;
}

Status decode_secret_file_size(long *file_size, DecodeInfo *decInfo)
{
    int size = 0;
    decode_size_from_lsb(&size, decInfo);
    *file_size = size;
    return e_success;
}

Status decode_secret_file_data(DecodeInfo *decInfo)
{
    char buffer[8];
    char ch;

    for (int i = 0; i < decInfo->secret_file_size; i++)
    {
        fread(buffer, 8, 1, decInfo->fptr_stego_image);
        ch = decode_byte_from_lsb(buffer);
        fwrite(&ch, 1, 1, decInfo->fptr_output_file);
    }
    return e_success;
}

Status do_decoding(DecodeInfo *decInfo)
{
    if (open_decode_files(decInfo) == e_failure)
    {
        printf("Failed to open decode files\n");
        return e_failure;
    }
    printf("Open files is success\n");

    if (decode_magic_string(decInfo) == e_failure)
    {
        printf("Magic string mismatch or failure\n");
        return e_failure;
    }
    printf("Magic string decoded successfully\n");

    if (decode_secret_file_extn_size(&decInfo->extn_size, decInfo) == e_failure)
    {
        printf("Failed to decode secret file extension size\n");
        return e_failure;
    }
    printf("Secret file extension size decoded successfully\n");

    if (decode_secret_file_extn(decInfo->extn_secret_file, decInfo) == e_failure)
    {
        printf("Failed to decode secret file extension\n");
        return e_failure;
    }
    printf("Secret file extension decoded successfully: %s\n", decInfo->extn_secret_file);

    if (decode_secret_file_size(&decInfo->secret_file_size, decInfo) == e_failure)
    {
        printf("Failed to decode secret file size\n");
        return e_failure;
    }
    printf("Secret file size decoded successfully: %ld\n", decInfo->secret_file_size);

    if (decode_secret_file_data(decInfo) == e_failure)
    {
        printf("Failed to decode secret file data\n");
        return e_failure;
    }
    printf("Secret file data decoded successfully into %s\n", decInfo->output_fname);

    fclose(decInfo->fptr_stego_image);
    fclose(decInfo->fptr_output_file);

    return e_success;
}