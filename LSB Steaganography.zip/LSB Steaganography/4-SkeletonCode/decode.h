#ifndef DECODE_H
#define DECODE_H

#include <stdio.h>
#include "types.h"

typedef struct _DecodeInfo
{
    char *stego_image_fname;
    FILE *fptr_stego_image;

    char *output_fname;
    FILE *fptr_output_file;

    char magic_string[3];
    int extn_size;
    char extn_secret_file[5];
    long secret_file_size;

} DecodeInfo;

Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);
Status do_decoding(DecodeInfo *decInfo);
Status open_decode_files(DecodeInfo *decInfo);
char decode_byte_from_lsb(char *image_buffer);
Status decode_data_from_image(char *data, int size, DecodeInfo *decInfo);
Status decode_magic_string(DecodeInfo *decInfo);
Status decode_secret_file_extn_size(int *extn_size, DecodeInfo *decInfo);
Status decode_secret_file_extn(char *file_extn, DecodeInfo *decInfo);
Status decode_secret_file_size(long *file_size, DecodeInfo *decInfo);
Status decode_secret_file_data(DecodeInfo *decInfo);
Status decode_size_from_lsb(int *size, DecodeInfo *decInfo);

#endif