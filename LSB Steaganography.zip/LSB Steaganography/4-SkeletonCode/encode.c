#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "common.h"

uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    fseek(fptr_image, 18, SEEK_SET);
    fread(&width, sizeof(int), 1, fptr_image);
    fread(&height, sizeof(int), 1, fptr_image);
    return width * height * 3;
}

uint get_file_size(FILE *fptr)
{
    fseek(fptr, 0L, SEEK_END);
    return ftell(fptr);
}

Status open_files(EncodeInfo *encInfo)
{
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    if (encInfo->fptr_src_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);
        return e_failure;
    }

    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    if (encInfo->fptr_secret == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);
        return e_failure;
    }

    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    if (encInfo->fptr_stego_image == NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);
        return e_failure;
    }

    return e_success;
}

Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    if (argv[2] != NULL && strstr(argv[2], ".bmp") != NULL)
    {
        encInfo->src_image_fname = argv[2];
    }
    else
    {
        printf("Invalid source image file\n");
        return e_failure;
    }

    if (argv[3] != NULL && strstr(argv[3], ".") != NULL)
    {
        encInfo->secret_fname = argv[3];
    }
    else
    {
        printf("Invalid secret file\n");
        return e_failure;
    }

    if (argv[4] == NULL)
    {
        encInfo->stego_image_fname = "stego.bmp";
    }
    else
    {
        encInfo->stego_image_fname = argv[4];
    }

    return e_success;
}

Status check_capacity(EncodeInfo *encInfo)
{
    encInfo->image_capacity = get_image_size_for_bmp(encInfo->fptr_src_image);
    encInfo->size_secret_file = get_file_size(encInfo->fptr_secret);

    long required_capacity = (strlen(MAGIC_STRING) + sizeof(int) + 4 + sizeof(long) + encInfo->size_secret_file) * 8;

    if (encInfo->image_capacity > (required_capacity + 54))
    {
        return e_success;
    }
    else
    {
        return e_failure;
    }
}

Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    char arr[54];
    fseek(fptr_src_image, 0, SEEK_SET);
    fread(arr, 54, 1, fptr_src_image);
    fwrite(arr, 54, 1, fptr_dest_image);
    return e_success;
}

Status encode_byte_to_lsb(char data, char *image_buffer)
{
    for (int i = 0; i < 8; i++)
    {
        image_buffer[i] = (image_buffer[i] & 0xFE) | ((data >> (7 - i)) & 0x01);
    }
    return e_success;
}

Status encode_data_to_image(char *data, int size, EncodeInfo *encInfo)
{
    for (int i = 0; i < size; i++)
    {
        fread(encInfo->image_data, 8, 1, encInfo->fptr_src_image);
        encode_byte_to_lsb(data[i], encInfo->image_data);
        fwrite(encInfo->image_data, 8, 1, encInfo->fptr_stego_image);
    }
    return e_success;
}

Status encode_magic_string(const char *magic_string, EncodeInfo *encInfo)
{
    encode_data_to_image((char *)magic_string, strlen(magic_string), encInfo);
    return e_success;
}

Status encode_size_to_lsb(int size, EncodeInfo *encInfo)
{
    char str[32];
    fread(str, 32, 1, encInfo->fptr_src_image);

    for (int i = 0; i < 32; i++)
    {
        str[i] = (str[i] & 0xFE) | ((size >> (31 - i)) & 1);
    }
    fwrite(str, 32, 1, encInfo->fptr_stego_image);
    return e_success;
}

Status encode_secret_file_extn_size(int extn_size, EncodeInfo *encInfo)
{
    encode_size_to_lsb(extn_size, encInfo);
    return e_success;
}

Status encode_secret_file_extn(char *file_extn, EncodeInfo *encInfo)
{
    encode_data_to_image(file_extn, strlen(file_extn), encInfo);
    return e_success;
}

Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    encode_size_to_lsb((int)file_size, encInfo);
    return e_success;
}

Status encode_secret_file_data(EncodeInfo *encInfo)
{
    rewind(encInfo->fptr_secret);
    char *str = malloc(encInfo->size_secret_file);
    fread(str, encInfo->size_secret_file, 1, encInfo->fptr_secret);
    encode_data_to_image(str, encInfo->size_secret_file, encInfo);
    free(str);
    return e_success;
}

Status copy_remaining_img_data(EncodeInfo *encInfo)
{
    char ch;
    while (fread(&ch, 1, 1, encInfo->fptr_src_image) > 0)
    {
        fwrite(&ch, 1, 1, encInfo->fptr_stego_image);
    }
    return e_success;
}

Status do_encoding(EncodeInfo *encInfo)
{
    if (open_files(encInfo) == e_failure)
    {
        printf("Failed to open files\n");
        return e_failure;
    }
    printf("Open files is success\n");

    if (check_capacity(encInfo) == e_failure)
    {
        printf("Image size is not sufficient enough to fit secret data\n");
        return e_failure;
    }
    printf("Secret data can fit in image file\n");

    if (copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_failure)
    {
        printf("Copy bmp header is failure\n");
        return e_failure;
    }
    printf("BMP header copied successfully\n");

    if (encode_magic_string(MAGIC_STRING, encInfo) == e_failure)
    {
        printf("Magic string encoding is failure\n");
        return e_failure;
    }
    printf("Magic string encoded successfully\n");

    char *extn = strstr(encInfo->secret_fname, ".");
    if (extn == NULL)
    {
        printf("Invalid secret file extension\n");
        return e_failure;
    }
    strcpy(encInfo->extn_secret_file, extn);
    printf("File extension of secret file is %s\n", encInfo->extn_secret_file);

    if (encode_secret_file_extn_size(strlen(encInfo->extn_secret_file), encInfo) == e_failure)
    {
        printf("Failed to encode file extension size\n");
        return e_failure;
    }
    printf("File extension size is encoded successfully\n");

    if (encode_secret_file_extn(encInfo->extn_secret_file, encInfo) == e_failure)
    {
        printf("Failed to encode file extension\n");
        return e_failure;
    }
    printf("Encoded file extn successfully\n");

    if (encode_secret_file_size(encInfo->size_secret_file, encInfo) == e_failure)
    {
        printf("Failed to encode file size\n");
        return e_failure;
    }
    printf("File size is encoded successfully\n");

    if (encode_secret_file_data(encInfo) == e_failure)
    {
        printf("Failed to encode secret file data\n");
        return e_failure;
    }
    printf("Secret file data is encoded successfully\n");

    if (copy_remaining_img_data(encInfo) == e_failure)
    {
        printf("Failed to copy remaining image data\n");
        return e_failure;
    }
    printf("Remaining image data is copied successfully\n");

    return e_success;
}