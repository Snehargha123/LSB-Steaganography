#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

OperationType check_operation_type(char *argv[])
{
    if (strcmp(argv[1], "-e") == 0)
    {
        return e_encode;
    }
    else if (strcmp(argv[1], "-d") == 0)
    {
        return e_decode;
    }
    else
    {
        return e_unsupported;
    }
}

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        printf("Usage:\n");
        printf("For encoding: ./a.out -e beautiful.bmp secret.txt [stego.bmp]\n");
        printf("For decoding: ./a.out -d stego.bmp [output.txt]\n");
        return 0;
    }

    OperationType res = check_operation_type(argv);

    if (res == e_encode)
    {
        printf("Encoding operation is selected\n");
        EncodeInfo encInfo;
        if (read_and_validate_encode_args(argv, &encInfo) == e_success)
        {
            printf("Read and validate encode args is successful\n");
            if (do_encoding(&encInfo) == e_success)
            {
                printf("Encoding is successful\n");
            }
            else
            {
                printf("Encoding failed\n");
            }
        }
        else
        {
            printf("Read and validate encode args failed\n");
        }
    }
    else if (res == e_decode)
    {
        printf("Decoding operation is selected\n");
        DecodeInfo decInfo;
        if (read_and_validate_decode_args(argv, &decInfo) == e_success)
        {
            printf("Read and validate decode args is successful\n");
            if (do_decoding(&decInfo) == e_success)
            {
                printf("Decoding is successful\n");
            }
            else
            {
                printf("Decoding failed\n");
            }
        }
        else
        {
            printf("Read and validate decode args failed\n");
        }
    }
    else
    {
        printf("Invalid operation type\n");
        printf("Usage:\n");
        printf("For encoding: ./a.out -e beautiful.bmp secret.txt [stego.bmp]\n");
        printf("For decoding: ./a.out -d stego.bmp [output.txt]\n");
    }

    return 0;
}